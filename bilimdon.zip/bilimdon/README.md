# bebanggis
![Author](https://img.shields.io/badge/design%20by-shaddamah-blue)
![Author](https://img.shields.io/badge/programming%20by-adriandk-blue)
![GitHub watches](https://img.shields.io/github/stars/adriandk/bebanggis-app?style=social)
![GitHub top language](https://img.shields.io/github/languages/top/adriandk/bebanggis-app)
![GitHub last commit](https://img.shields.io/github/last-commit/adriandk/bebanggis-app)

bebanggis is an android app project with purpose to help kids learn English

## Features
* **Attractive Layout**
* **Games and quiz**
* **Learn alphabets with voice sounds**
* **Mixing color games**

## Installation
Simply Download/Clone to your drive and open the project folder with [Android Studio](https://developer.android.com/studio) to get started

## Team Member / Contributor
* **Programming by** [Adrian Daniel](https://github.com/adriandk)
* **Design and concept by** [Shaddam Amru Hasibuan](https://github.com/Shaddamah)

## Contributing
Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
Please make sure to update tests as appropriate.

## License
[MIT](https://choosealicense.com/licenses/mit/)
